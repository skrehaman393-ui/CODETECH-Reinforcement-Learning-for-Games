# Reinforcement Learning for Games
## Tic-Tac-Toe AI using Q-Learning

**Author:** Shaik Rehaman

### Project Description
This project develops a Tic-Tac-Toe AI agent using Reinforcement Learning.
The agent learns to choose moves through repeated games against a random opponent.

### Technologies Used
- Python
- NumPy
- Pandas
- Matplotlib
- Joblib
- Q-Learning

### Algorithm
The project uses tabular Q-Learning with an epsilon-greedy policy.

### Training
The agent is trained for 30,000 episodes and evaluated over 3,000 games.

### Results
The notebook displays the AI's wins, draws, losses, and training performance graphs.

### How to Run
1. Open the notebook in Google Colab.
2. Run all cells.
3. Check the models and outputs folders for generated files.

### Note
This is an educational project. The AI is evaluated against a random opponent
and is not guaranteed to play optimally.
